# SD-Prompts-Checker for Firefox

Firefox Extension (Fork of Chrome Extension) to check PNG data embedded by Stable Diffusion

# Orginal

As sharing is caring and it allows any developer to modify my code
in such a way that it can become for example a Firefox extension/addon,
or implemented in to a webui, or even use it inside apps, or simply
beautify my Chrome Extension.

There is no need to provide any reference to me, but any coffee you
can buy for me at https://www.buymeacoffee.com/iamhunter69 is very much
appreciated so I can eventually and hopefully upgrade my computer
to do more hardcore work such as training a completely new
checkpoint/model from scratch based on 3 million 1024/1280 images
instead of everyone their low amount of 512/768 images

- Hunter
